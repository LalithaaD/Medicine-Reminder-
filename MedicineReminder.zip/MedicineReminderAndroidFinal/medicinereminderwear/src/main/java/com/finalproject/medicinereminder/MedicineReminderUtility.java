package com.finalproject.medicinereminder;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import com.finalproject.medicinereminder.Models.MedicinesModel;
import com.finalproject.medicinereminder.activity.Reminders.AlarmScheduler;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MedicineReminderUtility {
    public static final String PREF_NAME = "MedicineReminder";
    public static final String KEY_MEDICINE_LIST = "medicine_list";
    public static final String CHANNEL_ID = "MedicineReminderChannel";
    public static final String CHANNEL_NAME = "MedicineReminder";
    public static final String CHANNEL_DESCRIPTION = "Medicine Reminder Channel";

    // To Save the medicine list
    public static void saveMedicineList(Context context, List<MedicinesModel> medicineList) {
        try
        {
            SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            // Convert the list to JSON
            Gson gson = new Gson();
            String json = gson.toJson(medicineList);
            // Save the JSON string
            editor.putString(KEY_MEDICINE_LIST, json);
            editor.apply();
            Toast.makeText(context, "Medicines Updated !", Toast.LENGTH_SHORT).show();
            AlarmScheduler.scheduleAlarms(context);
        }
        catch (Exception e)
        {
            Toast.makeText(context,"Medicine not updated !", Toast.LENGTH_SHORT).show();
        }

    }

    // Retrieve the medicine list
    public static List<MedicinesModel> getMedicineList(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = sharedPreferences.getString(KEY_MEDICINE_LIST, null);

        if (json == null) {
            return new ArrayList<>(); // Return an empty list if no data is found
        }
        // Convert JSON string back to list
        Gson gson = new Gson();
        //The following is used to obtain the generic type information for the List<MedicinesModel> class when deserializing JSON using Gson.
       //The use of TypeToken is necessary whenever you need Gson to handle generic types correctly. It provides Gson with the detailed type information required to deserialize JSON into the desired type, such as List<MedicinesModel>.
        Type type = new TypeToken<List<MedicinesModel>>() {}.getType();
        return gson.fromJson(json, type);
    }

}