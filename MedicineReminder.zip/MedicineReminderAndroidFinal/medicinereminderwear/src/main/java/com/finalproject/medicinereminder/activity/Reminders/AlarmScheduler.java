package com.finalproject.medicinereminder.activity.Reminders;

import android.content.Context;

import com.finalproject.medicinereminder.MedicineReminderUtility;
import com.finalproject.medicinereminder.Models.MedicinesModel;

import java.util.List;

public class AlarmScheduler {

    public static void scheduleAlarms(Context context) {
        System.out.println("Alarm Scheduler");
        // Retrieve the list from SharedPreferences
        List<MedicinesModel> medicineList = MedicineReminderUtility.getMedicineList(context);

        // Iterate through the list and schedule alarms
        for (MedicinesModel medicine : medicineList) {
            if(medicineList.get(medicineList.indexOf(medicine)).getStatus().equals("set")) {
                AlarmHelper.setAlarm(context, medicine.getMedicineName(), medicine.getRemindertime());
            }
            }
    }
}
