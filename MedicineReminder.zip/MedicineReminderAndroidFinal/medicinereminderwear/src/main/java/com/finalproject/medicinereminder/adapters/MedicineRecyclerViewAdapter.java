package com.finalproject.medicinereminder.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TimePicker;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.finalproject.medicinereminder.MedicineReminderUtility;
import com.finalproject.medicinereminder.Models.MedicinesModel;
import com.finalproject.medicinereminder.R;
import com.finalproject.medicinereminder.activity.Medicines.WearMedicinesActivity;
import com.finalproject.medicinereminder.activity.Reminders.AlarmScheduler;
import com.finalproject.medicinereminder.activity.WearMainActivity;
import com.finalproject.medicinereminder.databinding.RowLayoutMedicinesBinding;

import java.util.ArrayList;
import java.util.List;

public class MedicineRecyclerViewAdapter extends RecyclerView.Adapter<MedicineRecyclerViewAdapter.ViewHolder>{
    List<MedicinesModel> medicineList;
    WearMedicinesActivity medicineActivity;
    RowLayoutMedicinesBinding rowBinding;
    Context context;

    //Initialize the adapter
     public MedicineRecyclerViewAdapter(Context context,List<MedicinesModel> medicineList)
     {
        this.context=context;
        this.medicineList=medicineList;
     }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater= LayoutInflater.from(context);
        rowBinding=RowLayoutMedicinesBinding.inflate(layoutInflater,parent,false);
        return new ViewHolder(rowBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MedicinesModel medicine=medicineList.get(position);
        holder.bindView(medicine);
        holder.rowBinding.btnRowDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Write the code to delete the medicine from the list and save it to shared preference
                medicineList.remove(medicine);
                updateMedicineList(medicineList,context);
                notifyDataSetChanged();
            }
        });
        holder.rowBinding.btnRowRemider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePicker timePicker=new TimePicker(context);
                timePicker.setIs24HourView(true);
                timePicker.setForegroundGravity(Gravity.CENTER_VERTICAL);
                AlertDialog.Builder dialog=new AlertDialog.Builder(context)
                        .setTitle("")
                        .setView(timePicker)
                        .setPositiveButton("Set", (dialog1, which) -> {
                           medicine.setRemindertime(timePicker.getHour()+":"+timePicker.getMinute());
                           medicine.setStatus("set");
                           medicineList.set(holder.getAdapterPosition(),medicine);
                           updateMedicineList(medicineList,context);
                           notifyDataSetChanged();
                           dialog1.dismiss();
                            Intent intent=new Intent(context, WearMainActivity.class);
                            context.startActivity(intent);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        })
                        .setNegativeButton("Cancel", (dialog1, which) -> {
                            dialog1.dismiss();
                        });
                dialog.show();

               //-------
            }
        });
    }

    @Override
    public int getItemCount() {
        return medicineList.size();
    }

    // Create the view holder
     public class ViewHolder extends RecyclerView.ViewHolder {

         RowLayoutMedicinesBinding rowBinding;
         public ViewHolder(RowLayoutMedicinesBinding medicinesBinding) {
             super(medicinesBinding.getRoot());
             this.rowBinding=medicinesBinding;
         }
         public void bindView(MedicinesModel medicineModel)
         {
             if(medicineModel.getRemindertime()==null || medicineModel.getRemindertime().equals(""))
             {
                 rowBinding.tvRowMedReminder.setText("No Reminder Set");
             }
             else
             {
                 rowBinding.tvRowMedReminder.setText("Reminder Set at :"+medicineModel.getRemindertime());
             }
             rowBinding.tvRowMedName.setText(medicineModel.getMedicineName());
         }
     }

     private void updateMedicineList(List<MedicinesModel> medicineList,Context context) {

         List<MedicinesModel> savedList = MedicineReminderUtility.getMedicineList(context);
         savedList.clear();
         savedList.addAll(medicineList);
         MedicineReminderUtility.saveMedicineList(context, savedList);
     }


}
