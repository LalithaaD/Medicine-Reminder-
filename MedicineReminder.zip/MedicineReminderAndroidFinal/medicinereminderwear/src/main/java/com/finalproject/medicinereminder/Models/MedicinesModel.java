package com.finalproject.medicinereminder.Models;

public class MedicinesModel {
    public String medicineName;
    public String remindertime;
    //set,taken,snooze,missed,completed
    public String status;

    public MedicinesModel(String medicineName) {
        this.medicineName = medicineName;
        this.remindertime ="";
        this.status="";
    }

    public String getMedicineName() {
        return medicineName;
    }
    public void setMedicineName(String medicineName) {
        this.medicineName = medicineName;
    }

    public String getRemindertime() {
        return remindertime;
    }

    public void setRemindertime(String remindertime) {
        this.remindertime = remindertime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
